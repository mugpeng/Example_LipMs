library(testthat)
library(protti)

test_check("protti")
